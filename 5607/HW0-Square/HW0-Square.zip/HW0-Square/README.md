![Alt text](HW0.png?raw=true)
