/**
 * Created by schra447 on 2/23/16.
 */
public class Contact {
    private String name = "";
    private long phone = 0;
    private String address = "";
    private String comments = "";
    public Contact(String name, String address, long phone, String comments){
        this.name = name;
        this.address = address;
        this.phone = phone;
        this.comments = comments;
    }
    public static void main(String[] args){
        Contact c = new Contact("name","address",3206303243L,"comment");
        Contact c1 = new Contact("name","address",3206303243L,"comment");
        System.out.println(c.toSting());
        System.out.println(c.equals(c1));
        System.out.println("------------");
        c.setName("new name");
        c.setPhone(3204682749L);
        c.setAddress("new address");
        c.setComments("new comment");
        System.out.println(c.toSting());
        System.out.println(c.equals(c1));
    }
    public void setName(String name){
        this.name = name;
    }
    public void setPhone(long number){
        phone = number;
    }
    public void setAddress(String address){
        this.address = address;
    }
    public void setComments(String comments){
        this.comments = comments;
    }
    public String getName(){
        return name;
    }
    public long getPhone(){
        return phone;
    }
    public String getAddress(){
        return address;
    }
    public String getComments(){
        return comments;
    }
    public String toSting(){
        String phoneNum = Long.toString(phone);
        if(phoneNum.length() < 2){
            phoneNum = "";
        }
        return name +"\n" + address + "\n" + Long.toString(this.phone) + "\n" + comments;
    }
    public boolean equals(Contact c){
        if(c.getName().equals(name)){
            if(c.getAddress().equals(address)){
                if(c.getComments().equals(comments)){
                    if(c.getPhone() == phone)
                        return true;
                }
            }
        }
        return false;
    }
}
