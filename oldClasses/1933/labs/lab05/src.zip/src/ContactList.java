import java.io.File;
import java.io.PrintWriter;
import java.security.spec.ECField;
import java.util.Scanner;

/**
 * Created by schra447 on 2/23/16.
 */
public class ContactList {
    private int ptr = -1;
    private int counter = 0;
    private Contact[] contactList = new Contact[0];
    public static void main(String[] args){
        Contact c = new Contact("name1","address1",3206303243L,"comments1");
        Contact c1 = new Contact("test","address2",3206303244L,"comments2");
        Contact c2 = new Contact("random","address3",3206303245L,"comments3");
        ContactList cl = new ContactList();
        cl.add(c);
        cl.add(c1);
        cl.add(c2);
        System.out.println(cl.write("testFile"));
        System.out.print(cl.read("testFile"));
    }
    public ContactList() {
        contactList = new Contact[20];
    }
    public ContactList(int length) {
        contactList = new Contact[length];
        System.out.println(contactList.length);
    }
    public boolean add(Contact c){
        for(int i = 0; i < contactList.length; i++){
            if(contactList[i] == null){
                contactList[i] = c;
                ptr = i;
                return true;
            }
        }
        return false;
    }
    public Contact find(String name){
        for(int i = ptr; i < contactList.length + ptr; i++){
            int j = i;
            if(i >= contactList.length){
                j = i - contactList.length;
            }
            if(contactList[j] != null) {
                if (contactList[j].getName().contains(name)) {
                    ptr = j;
                    return contactList[j];
                }
            }
        }
        return null;
    }
    public Contact remove(){
        Contact contact = contactList[ptr];
        contactList[ptr] = null;
        return contact;
    }
    public boolean read(String fileName){
        Scanner s = null;
        try{
            s = new Scanner(new File(fileName));
        }catch(Exception e){
            return false;
        }
        return true;
    }
    public boolean write(String fileName){
        PrintWriter p = null;
        try{
            p = new PrintWriter(new File(fileName));
        }catch(Exception e){
            return false;
        }
        for(int i = 0; i < contactList.length; i++){
            if(contactList[i] != null)
                p.println(contactList[i].toSting());
        }
        return true;
    }
}
